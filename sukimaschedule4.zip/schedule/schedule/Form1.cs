﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/*
 * 現在時刻から予定を追加する判定が可能（多分）日付を進める戻す、設定も可能
 * バージョン4(2022/12/9)
 * 大江祥暉
 */

namespace schedule
{
    public partial class Form1 : Form
    {

        //日付を進める戻す為の定数
        DateTime datetimebutton = DateTime.Now;
        //DateTime datetimebutton = DateTime.Parse();

        //日付を進める戻すグローバル変数
        int count = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }


        public Form1()
        {
            InitializeComponent();
            //タイマー起動
            timer1.Start();

        }

        
        //セットボタン
        private void button1_Click(object sender, EventArgs e)
        {
            //時間の範囲外入力の場合true問題なし:false問題あり
            Boolean timeflg = true;

            if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox3.Text == "" || comboBox4.Text == "")
            {
                timeflg = false;
            }


            if (timeflg == true)
            {
                //開始時間(時)と終了時間(時)の判定(14:00==14:59)
                if (int.Parse(comboBox1.Text) == int.Parse(comboBox3.Text))
                {
                    //開始時間(分)と終了時間(分)の判定(例14:30から14:40)
                    if (int.Parse(comboBox2.Text) < int.Parse(comboBox4.Text))
                    {
                        //計算
                        MessageBox.Show("OK");
                    }
                    else
                    {
                        MessageBox.Show("終了時間がおかしい");
                    }
                }
                //開始時間(時)と終了時間(時)の判定(14:00<15:00)
                else if (int.Parse(comboBox1.Text) < int.Parse(comboBox3.Text))
                {
                    //計算
                    MessageBox.Show("OK");
                }
                else
                {
                    MessageBox.Show("終了時間(時)が開始時間(時)より早い");
                }
            }
            else
            {
                MessageBox.Show("選択してください");
            }
            

        }


        //今日の時刻表示
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            // 現在時刻を取得 予定設定の時間用
            DateTime datetime = DateTime.Now;


            //現在時刻の表示
            label6.Text = datetime.ToString("yyyy/MM/dd HH:mm");
        }


        private void label6_Click(object sender, EventArgs e)
        {

        }

        //一日進む
        //ファイルを読み込むならこのタイミング
        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();


            //年月日
            //一日進める
            count++;
            //表示
            label6.Text = datetimebutton.AddDays(count).ToString("yyyy/MM/dd");


            //一致していれば現在の時刻を表示させ時間をリアルタイムにする(分が進む等)
            //現在時刻とボタンを押した先の時刻が同じかの判定
            Timehikaku();

        }

        //一日戻る
        //ファイルを読み込むならこのタイミング
        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();


            //年月日
            //一日戻る
            count--;
            //表示
            label6.Text = datetimebutton.AddDays(count).ToString("yyyy/MM/dd");

            //現在時刻とボタンを押した先の時刻が同じかの判定
            Timehikaku();

        }


        //現在時刻とボタンを押した先の時刻が同じかの判定関数
        public void Timehikaku()
        {
            // 現在時刻を取得 予定設定の時間用
            DateTime datetime = DateTime.Now;

            //一致していれば現在の時刻を表示させ時間をリアルタイムにする(分が進む等)
            if (datetime.Date == datetimebutton.AddYears(count).Date)
            {
                timer1.Start();
            }
        }

        // Allow Combo Box to center aligned
        private void cbxDesign_DrawItem(object sender, DrawItemEventArgs e)
        {
            // By using Sender, one method could handle multiple ComboBoxes
            ComboBox cbx = sender as ComboBox;
            
            if (cbx != null)
            {
                // Always draw the background
                e.DrawBackground();

                // Drawing one of the items?
                if (e.Index >= 0)
                {
                    // Set the string alignment.  Choices are Center, Near and Far
                    StringFormat sf = new StringFormat();
                    sf.LineAlignment = StringAlignment.Far;
                    sf.Alignment = StringAlignment.Far;
                    
                    // Set the Brush to ComboBox ForeColor to maintain any ComboBox color settings
                    // Assumes Brush is solid
                    Brush brush = new SolidBrush(cbx.ForeColor);

                    // If drawing highlighted selection, change brush
                    if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                        brush = SystemBrushes.HighlightText;

                    // Draw the string
                    e.Graphics.DrawString(cbx.Items[e.Index].ToString(), cbx.Font, brush, e.Bounds, sf);
                }
            }
        }



        //予定部分の四角の描画
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            /*
            // Graphicsオブジェクトの作成
            Graphics g = this.CreateGraphics();

            // penを作成
            Pen blackPen = new Pen(Color.Black, 2);
            
            // lineの始点と終点を設定
            //横
            Point Start_point1 = new Point(0, 270);
            Point End_point1 = new Point(540, 270);

            //左から縦1
            Point Start_point2 = new Point(135, 270);
            Point End_point2 = new Point(135, 410);

            //左から縦2
            Point Start_point3 = new Point(270, 270);
            Point End_point3 = new Point(270, 410);

            //左から縦3
            Point Start_point4 = new Point(405, 270);
            Point End_point4 = new Point(405, 410);

            //一番右
            Point Start_point5 = new Point(540, 270);
            Point End_point5 = new Point(540, 410);

            // lineを描画
            g.DrawLine(blackPen, Start_point1, End_point1);
            g.DrawLine(blackPen, Start_point2, End_point2);
            g.DrawLine(blackPen, Start_point3, End_point3);
            g.DrawLine(blackPen, Start_point4, End_point4);
            g.DrawLine(blackPen, Start_point5, End_point5);

            // penを解放する
            blackPen.Dispose();
            

            e.Graphics.FillRectangle(Brushes.White, 0, 270, 540, 270);
            e.Graphics.DrawRectangle(Pens.Black, 0, 270, 500, 260);

            // Graphicsを解放する
            g.Dispose();
            */
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
